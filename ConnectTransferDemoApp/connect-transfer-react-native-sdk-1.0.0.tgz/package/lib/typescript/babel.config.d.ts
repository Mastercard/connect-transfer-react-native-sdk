export let presets: string[];
export let plugins: string[];
//# sourceMappingURL=babel.config.d.ts.map