import 'react-native-url-polyfill/auto';
/**
 * Extracts base URL, query parameters string, and query parameters as an object from a given partner URL.
 *
 * @param {string} url - The URL from which to extract data.
 * @returns {{ baseURL: string; queryParams: string; queryParamsObject: Record<string, string> }}
 * - An object containing:
 *   - baseURL: The base URL of the partner URL.
 *   - queryParams: The raw query parameters string, including the '?' prefix.
 *   - queryParamsObject: An object mapping query parameter keys to their respective values.
 */
export declare const extractUrlData: (url?: string) => {
    baseURL: string;
    queryParams: string;
    queryParamsObject: Record<string, string>;
};
/**
 * Formats the current date and time to "yyyy-MM-dd'T'HH:mm:ssZ" format.
 * @returns {string} The formatted current date and time.
 */
export declare const formatCurrentDateTime: () => string;
/**
 * Generate the URL based on the current app language and the type of webpage (Terms or Privacy).
 * @param {string} language - The current app language ('en' or 'es').
 * @param {string} type - The type of page ('termsOfUse' or 'privacyPolicy').
 * @returns {string} - The URL for the specified page.
 */
export declare const getURL: (language: string, type: "termsOfUse" | "privacy") => string | null;
/**
 * Open a URL in the InAppBrowser or fallback to the default browser.
 * @param {string} url - The URL to open.
 */
export declare const openLink: (url: string) => Promise<void>;
export declare const getTranslation: (text: string, esJson: Record<string, string>) => string;
//# sourceMappingURL=utils.d.ts.map