declare const store: import("@reduxjs/toolkit").EnhancedStore<{
    user: {
        modalVisible: boolean;
        url: string;
        baseURL: string;
        queryParams: string;
        queryParamsObject: {};
        language: string;
        loading: boolean;
        data: null;
        error: null;
    };
    termsAndPolicies: {
        loading: boolean;
        data: null;
        error: null;
    };
    complete: {
        loading: boolean;
        data: null;
        error: null;
    };
    event: import("../slices/eventHandlerSlice").EventHandlersState;
    errorTranslation: {
        loading: boolean;
        data: null;
        error: null;
    };
}, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<{
        user: {
            modalVisible: boolean;
            url: string;
            baseURL: string;
            queryParams: string;
            queryParamsObject: {};
            language: string;
            loading: boolean;
            data: null;
            error: null;
        };
        termsAndPolicies: {
            loading: boolean;
            data: null;
            error: null;
        };
        complete: {
            loading: boolean;
            data: null;
            error: null;
        };
        event: import("../slices/eventHandlerSlice").EventHandlersState;
        errorTranslation: {
            loading: boolean;
            data: null;
            error: null;
        };
    }, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export default store;
//# sourceMappingURL=index.d.ts.map