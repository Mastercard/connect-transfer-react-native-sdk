import { type ConnectTransferEventHandler } from '../../containers/ConnectTransfer/transferEventConstants';
export interface EventHandlersState {
    eventHandler: ConnectTransferEventHandler | null;
}
export declare const setEventHandlers: import("@reduxjs/toolkit").ActionCreatorWithPayload<ConnectTransferEventHandler, "event/setEventHandlers">;
declare const _default: import("redux").Reducer<EventHandlersState>;
export default _default;
//# sourceMappingURL=eventHandlerSlice.d.ts.map