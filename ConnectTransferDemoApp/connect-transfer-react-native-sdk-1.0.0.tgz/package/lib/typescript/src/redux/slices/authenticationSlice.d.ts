export const authenticateUser: import("@reduxjs/toolkit").AsyncThunk<any, void, {
    state?: unknown;
    dispatch?: import("redux-thunk").ThunkDispatch<unknown, unknown, import("redux").UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
export const setUrl: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "user/setUrl">;
export const setUrlData: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "user/setUrlData">;
export const resetData: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"user/resetData">;
declare const _default: import("redux").Reducer<{
    modalVisible: boolean;
    url: string;
    baseURL: string;
    queryParams: string;
    queryParamsObject: {};
    language: string;
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
//# sourceMappingURL=authenticationSlice.d.ts.map