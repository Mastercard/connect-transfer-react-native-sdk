export function handleAsyncActions(builder: Object, action: Function): void;
//# sourceMappingURL=asyncHelper.d.ts.map