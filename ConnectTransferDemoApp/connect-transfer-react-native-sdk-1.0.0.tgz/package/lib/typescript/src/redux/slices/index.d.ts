export const rootReducer: import("redux").Reducer<{
    user: {
        modalVisible: boolean;
        url: string;
        baseURL: string;
        queryParams: string;
        queryParamsObject: {};
        language: string;
        loading: boolean;
        data: null;
        error: null;
    };
    termsAndPolicies: {
        loading: boolean;
        data: null;
        error: null;
    };
    complete: {
        loading: boolean;
        data: null;
        error: null;
    };
    event: import("./eventHandlerSlice").EventHandlersState;
    errorTranslation: {
        loading: boolean;
        data: null;
        error: null;
    };
}, import("redux").UnknownAction, Partial<{
    user: {
        modalVisible: boolean;
        url: string;
        baseURL: string;
        queryParams: string;
        queryParamsObject: {};
        language: string;
        loading: boolean;
        data: null;
        error: null;
    } | undefined;
    termsAndPolicies: {
        loading: boolean;
        data: null;
        error: null;
    } | undefined;
    complete: {
        loading: boolean;
        data: null;
        error: null;
    } | undefined;
    event: import("./eventHandlerSlice").EventHandlersState | undefined;
    errorTranslation: {
        loading: boolean;
        data: null;
        error: null;
    } | undefined;
}>>;
//# sourceMappingURL=index.d.ts.map