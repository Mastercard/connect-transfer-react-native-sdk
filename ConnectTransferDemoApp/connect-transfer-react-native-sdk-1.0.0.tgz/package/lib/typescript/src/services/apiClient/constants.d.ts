export const TIMEOUT: number;
export const HEADERS: {
    'Content-Type': string;
    Accept: string;
};
export namespace METHODS {
    let GET: string;
    let POST: string;
    let PUT: string;
    let DELETE: string;
    let OPTIONS: string;
}
export namespace ERROR_CODES {
    let BAD_REQUEST: number;
    let UNAUTHORIZED: number;
    let ACCESS_DENIED: number;
    let NOT_FOUND: number;
    let PASSWORD_FIELD_EMPTY: number;
    let NOT_MODIFIED: number;
    let SERVICE_UNAVAILABLE: number;
    let NO_NETWORK: string;
}
export namespace REQUEST_HEADER_TYPE {
    let HTML: string;
    let JSON: string;
}
//# sourceMappingURL=constants.d.ts.map