export const TIMEOUT: number;
export const HEADERS: {
    'Content-Type': string;
    Accept: string;
};
export namespace METHODS {
    let GET: string;
    let POST: string;
    let PUT: string;
    let DELETE: string;
    let OPTIONS: string;
}
//# sourceMappingURL=constants.d.ts.map