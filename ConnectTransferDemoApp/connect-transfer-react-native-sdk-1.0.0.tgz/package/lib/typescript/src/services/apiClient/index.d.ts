export function api(options: any): Promise<any>;
export default api;
//# sourceMappingURL=index.d.ts.map