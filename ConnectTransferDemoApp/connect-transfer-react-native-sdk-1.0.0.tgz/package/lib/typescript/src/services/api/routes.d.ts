export function generateRoute(key: any, state: any): string | null;
export function requestHeaders(key: any, state: any): {
    'Content-Type': string;
    Accept: string;
};
export function createApiActions(key: any): import("@reduxjs/toolkit").AsyncThunk<any, void, {
    state?: unknown;
    dispatch?: import("redux-thunk").ThunkDispatch<unknown, unknown, import("redux").UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
//# sourceMappingURL=routes.d.ts.map