export function termsAndPolicies(key: any): import("@reduxjs/toolkit").AsyncThunkAction<any, void, {
    state?: unknown;
    dispatch?: import("redux-thunk").ThunkDispatch<unknown, unknown, import("redux").UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
export function getData(language: any): {
    context: string;
    workflow: string;
    language: any;
    termsAndConditionsAcceptedDate: string;
    privacyPolicyAcceptedDate: string;
};
//# sourceMappingURL=termsAndPolicies.d.ts.map