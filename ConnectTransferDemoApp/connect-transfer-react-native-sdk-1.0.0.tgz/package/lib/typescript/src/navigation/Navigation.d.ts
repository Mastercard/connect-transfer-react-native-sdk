import { ConnectTransferEventHandler } from '../containers/ConnectTransfer/transferEventConstants';
declare const Navigation: React.FC<{
    url: string;
    eventHandlers: ConnectTransferEventHandler;
}>;
export default Navigation;
//# sourceMappingURL=Navigation.d.ts.map