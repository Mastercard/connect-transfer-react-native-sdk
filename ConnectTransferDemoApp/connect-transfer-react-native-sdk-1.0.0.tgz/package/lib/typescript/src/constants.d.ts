export declare const CONNECT_TRANSFER_SDK_VERSION: string;
//# sourceMappingURL=constants.d.ts.map