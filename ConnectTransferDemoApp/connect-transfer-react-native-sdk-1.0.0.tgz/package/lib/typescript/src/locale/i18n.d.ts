export default i18next;
import i18next from 'i18next';
//# sourceMappingURL=i18n.d.ts.map