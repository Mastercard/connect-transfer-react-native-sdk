export default MAAttributedText;
declare function MAAttributedText({ text, styledTexts, textStyle, component }: {
    text: any;
    styledTexts: any;
    textStyle: any;
    component?: null | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAAttributedText.d.ts.map