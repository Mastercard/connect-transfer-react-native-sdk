export default MAAttributedText;
declare function MAAttributedText({ text, styledTexts, textStyle, component }: {
    text?: string | undefined;
    styledTexts?: never[] | undefined;
    textStyle?: {} | undefined;
    component?: null | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAAttributedText.d.ts.map