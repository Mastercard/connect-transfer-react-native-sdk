export default ExitBottomSheet;
declare function ExitBottomSheet({ bottomSheetRef, onClose }: {
    bottomSheetRef: any;
    onClose: any;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ExitBottomSheet.d.ts.map