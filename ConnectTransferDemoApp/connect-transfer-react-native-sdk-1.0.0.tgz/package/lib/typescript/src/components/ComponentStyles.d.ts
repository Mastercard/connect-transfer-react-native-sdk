export namespace SecuredByStyle {
    namespace footer {
        let bottom: number;
        let left: number;
        let right: number;
        let padding: number;
        let flexDirection: "row";
        let justifyContent: "space-around";
    }
    namespace logoContainer {
        let flexDirection_1: "row";
        export { flexDirection_1 as flexDirection };
        export let alignItems: "center";
        export let width: number;
        export let height: number;
    }
    namespace securedText {
        let fontSize: number;
        let fontWeight: "350";
        let marginRight: number;
    }
    namespace logo {
        let resizeMode: "contain";
    }
}
export namespace MAButtonStyle {
    namespace button {
        let height_1: number;
        export { height_1 as height };
        export let backgroundColor: string;
        export let borderRadius: number;
        let justifyContent_1: "center";
        export { justifyContent_1 as justifyContent };
        let alignItems_1: "center";
        export { alignItems_1 as alignItems };
        export let marginBottom: number;
    }
    namespace buttonText {
        let fontSize_1: number;
        export { fontSize_1 as fontSize };
        export let color: string;
        let fontWeight_1: "bold";
        export { fontWeight_1 as fontWeight };
        export let lineHeight: number;
        export let letterSpacing: number;
    }
}
export namespace CrossDismissStyle {
    namespace crossIcon {
        let alignSelf: "flex-end";
    }
}
export namespace LoaderStyle {
    namespace container {
        let alignItems_2: "center";
        export { alignItems_2 as alignItems };
        let justifyContent_2: "center";
        export { justifyContent_2 as justifyContent };
    }
    namespace box {
        export let borderStyle: "solid";
        export let borderRightColor: string;
        export let borderBottomColor: string;
        let borderRadius_1: number;
        export { borderRadius_1 as borderRadius };
    }
}
export namespace ExitBottomSheetStyle {
    namespace content {
        let flex: number;
        let marginTop: number;
        let paddingBottom: number;
        let marginHorizontal: number;
    }
    namespace backdrop {
        let backgroundColor_1: string;
        export { backgroundColor_1 as backgroundColor };
    }
    namespace title {
        let color_1: string;
        export { color_1 as color };
        let fontSize_2: number;
        export { fontSize_2 as fontSize };
        let fontWeight_2: "bold";
        export { fontWeight_2 as fontWeight };
        let marginBottom_1: number;
        export { marginBottom_1 as marginBottom };
        let lineHeight_1: number;
        export { lineHeight_1 as lineHeight };
    }
    namespace subtitle {
        let fontSize_3: number;
        export { fontSize_3 as fontSize };
        let color_2: string;
        export { color_2 as color };
        let marginBottom_2: number;
        export { marginBottom_2 as marginBottom };
        let lineHeight_2: number;
        export { lineHeight_2 as lineHeight };
    }
    namespace exitButton {
        export let paddingVertical: number;
        let alignItems_3: "center";
        export { alignItems_3 as alignItems };
        let marginBottom_3: number;
        export { marginBottom_3 as marginBottom };
    }
    namespace exitButtonText {
        let color_3: string;
        export { color_3 as color };
        let fontWeight_3: "bold";
        export { fontWeight_3 as fontWeight };
    }
    namespace stayButton {
        let backgroundColor_2: string;
        export { backgroundColor_2 as backgroundColor };
        export let borderWidth: number;
        export let borderColor: string;
        let paddingVertical_1: number;
        export { paddingVertical_1 as paddingVertical };
        let alignItems_4: "center";
        export { alignItems_4 as alignItems };
    }
    namespace stayButtonText {
        let color_4: string;
        export { color_4 as color };
        let fontWeight_4: "bold";
        export { fontWeight_4 as fontWeight };
    }
}
//# sourceMappingURL=ComponentStyles.d.ts.map