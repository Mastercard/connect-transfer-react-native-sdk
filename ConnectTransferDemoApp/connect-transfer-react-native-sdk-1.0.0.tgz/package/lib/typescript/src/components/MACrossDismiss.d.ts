export default MACrossDismiss;
declare function MACrossDismiss({ style, onCrossPress }: {
    style: any;
    onCrossPress: any;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MACrossDismiss.d.ts.map