export default MACrossDismiss;
declare function MACrossDismiss({ style, onCrossPress }: {
    style?: {} | undefined;
    onCrossPress?: (() => void) | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MACrossDismiss.d.ts.map