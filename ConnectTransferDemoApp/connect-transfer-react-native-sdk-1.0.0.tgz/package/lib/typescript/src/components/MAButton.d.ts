export default MAButton;
declare function MAButton(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAButton.d.ts.map