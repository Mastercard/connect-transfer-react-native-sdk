export default MALoader;
declare function MALoader({ size, color, strokeWidth, borderRadius }: {
    size?: number | undefined;
    color?: string | undefined;
    strokeWidth?: number | undefined;
    borderRadius?: number | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MALoader.d.ts.map