export default MASecuredBy;
declare function MASecuredBy(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MASecuredBy.d.ts.map