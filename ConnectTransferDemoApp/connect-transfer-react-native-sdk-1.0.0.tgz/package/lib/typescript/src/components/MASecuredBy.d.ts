export default MASecuredBy;
declare function MASecuredBy(testID: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MASecuredBy.d.ts.map