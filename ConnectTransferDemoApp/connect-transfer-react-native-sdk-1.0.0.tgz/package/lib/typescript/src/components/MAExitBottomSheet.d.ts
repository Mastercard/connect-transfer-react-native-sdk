export default MAExitBottomSheet;
declare function MAExitBottomSheet({ bottomSheetRef, onClose }: {
    bottomSheetRef: any;
    onClose: any;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAExitBottomSheet.d.ts.map