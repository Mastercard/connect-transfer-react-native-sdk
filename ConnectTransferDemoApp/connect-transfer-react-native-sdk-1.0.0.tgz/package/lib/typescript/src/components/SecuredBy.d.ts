export default SecuredBy;
declare function SecuredBy({ style }: {
    style?: {} | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=SecuredBy.d.ts.map