export default Loader;
declare function Loader({ size, color, strokeWidth, borderRadius }: {
    size?: number | undefined;
    color?: string | undefined;
    strokeWidth?: number | undefined;
    borderRadius?: number | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Loader.d.ts.map