export default CrossDismiss;
declare function CrossDismiss({ style, onCrossPress }: {
    style?: {} | undefined;
    onCrossPress?: (() => void) | undefined;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CrossDismiss.d.ts.map