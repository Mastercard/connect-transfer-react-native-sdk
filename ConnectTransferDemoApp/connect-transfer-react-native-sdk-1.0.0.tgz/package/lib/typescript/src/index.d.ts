import 'react-native-gesture-handler';
import { type ConnectTransferProps } from './containers/types';
declare const ConnectTransfer: React.FC<ConnectTransferProps>;
export default ConnectTransfer;
//# sourceMappingURL=index.d.ts.map