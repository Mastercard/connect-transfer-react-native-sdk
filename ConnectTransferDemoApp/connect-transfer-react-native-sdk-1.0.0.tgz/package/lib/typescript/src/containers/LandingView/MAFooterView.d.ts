export default MAFooterView;
declare function MAFooterView({ onNextPress }: {
    onNextPress: any;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAFooterView.d.ts.map