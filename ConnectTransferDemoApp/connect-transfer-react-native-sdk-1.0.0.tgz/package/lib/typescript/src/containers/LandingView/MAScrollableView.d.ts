export default MAScrollableView;
declare function MAScrollableView(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MAScrollableView.d.ts.map