import React from 'react';
import { type MALandingViewProps } from '../types';
declare const MALandingView: React.FC<MALandingViewProps>;
export default MALandingView;
//# sourceMappingURL=MALandingView.d.ts.map