export namespace ErrorScreenStyles {
    namespace errorView {
        let flex: number;
        let marginHorizontal: number;
    }
    namespace safeAreaView {
        let flex_1: number;
        export { flex_1 as flex };
        export let backgroundColor: string;
    }
    namespace titleText {
        let marginTop: number;
        let fontSize: number;
        let fontWeight: "bold";
        let color: string;
    }
    namespace descriptionText {
        let marginTop_1: number;
        export { marginTop_1 as marginTop };
        let fontSize_1: number;
        export { fontSize_1 as fontSize };
        let fontWeight_1: "normal";
        export { fontWeight_1 as fontWeight };
        let color_1: string;
        export { color_1 as color };
    }
    namespace errorIcon {
        let marginTop_2: number;
        export { marginTop_2 as marginTop };
        export let alignSelf: "center";
    }
    namespace footerView {
        let bottom: number;
        let position: "absolute";
        let width: "100%";
    }
    namespace tryAgainButton {
        let marginHorizontal_1: number;
        export { marginHorizontal_1 as marginHorizontal };
    }
    namespace returnToPartnerButton {
        let marginTop_3: number;
        export { marginTop_3 as marginTop };
        let marginHorizontal_2: number;
        export { marginHorizontal_2 as marginHorizontal };
        let backgroundColor_1: string;
        export { backgroundColor_1 as backgroundColor };
        export let borderWidth: number;
        export let borderColor: string;
        export let paddingVertical: number;
        export let alignItems: "center";
    }
    namespace returnToPartnerText {
        let color_2: string;
        export { color_2 as color };
        let fontWeight_2: "bold";
        export { fontWeight_2 as fontWeight };
    }
}
//# sourceMappingURL=Styles.d.ts.map