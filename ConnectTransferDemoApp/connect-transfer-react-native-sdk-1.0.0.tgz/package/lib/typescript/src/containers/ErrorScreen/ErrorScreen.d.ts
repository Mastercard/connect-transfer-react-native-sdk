import { type ErrorScreenProps } from '../types';
declare const ErrorScreen: React.FC<ErrorScreenProps>;
export default ErrorScreen;
//# sourceMappingURL=ErrorScreen.d.ts.map