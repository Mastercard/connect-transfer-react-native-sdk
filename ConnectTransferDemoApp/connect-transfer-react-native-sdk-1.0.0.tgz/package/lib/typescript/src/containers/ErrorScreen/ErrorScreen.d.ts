declare const ErrorScreen: React.FC;
export default ErrorScreen;
//# sourceMappingURL=ErrorScreen.d.ts.map