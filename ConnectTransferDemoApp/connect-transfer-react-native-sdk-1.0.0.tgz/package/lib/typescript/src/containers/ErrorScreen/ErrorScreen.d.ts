declare const ErrorScreen: React.FC<{
    isExperienceError?: boolean;
}>;
export default ErrorScreen;
//# sourceMappingURL=ErrorScreen.d.ts.map