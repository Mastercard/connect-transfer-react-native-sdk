export default MARedirectingView;
declare function MARedirectingView(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=MARedirectingView.d.ts.map