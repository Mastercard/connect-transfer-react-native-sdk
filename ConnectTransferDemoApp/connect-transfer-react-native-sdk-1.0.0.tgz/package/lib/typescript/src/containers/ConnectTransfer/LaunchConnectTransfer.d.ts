declare const LaunchConnectTransfer: () => import("react/jsx-runtime").JSX.Element;
export default LaunchConnectTransfer;
//# sourceMappingURL=LaunchConnectTransfer.d.ts.map