export declare const getTransferProductType: (product: any) => string | null;
export declare const useTransferEventCommonData: () => Record<string, string | undefined>;
export declare const useTransferEventResponse: () => {
    getResponseForInitializeTransfer: () => Record<string, any> | undefined;
    getResponseForTermsAndConditionsAccepted: () => Record<string, any> | undefined;
    getResponseForInitializeDepositSwitch: (productType?: string) => Record<string, any> | undefined;
    getResponseForError: (errorCode?: string) => Record<string, any> | undefined;
    getResponseForClose: (reason: string, errorCode?: string) => Record<string, any> | undefined;
    getResponseForFinish: (responseData: Record<string, any>) => Record<string, any> | undefined;
};
export declare const getUserEventMappingForPDS: (interactionResponse: any, commonData: any) => any;
export declare const getCommonUserEventMapping: (interactionResponse: any, commonData: any) => any;
//# sourceMappingURL=transferEventHandlers.d.ts.map