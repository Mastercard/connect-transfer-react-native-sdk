export declare const getTransferProductType: (product: any) => string | null;
export declare const useTransferEventCommonData: () => Record<string, string | undefined>;
export declare const useTransferEventResponse: () => {
    getResponseForInitializeTransfer: () => Record<string, any>;
    getResponseForTermsAndConditionsAccepted: () => Record<string, any>;
    getResponseForInitializeDepositSwitch: (productType?: string) => Record<string, any>;
    getResponseForClose: (reason: string, errorCode?: string) => Record<string, any>;
    getResponseForFinish: (responseData: Record<string, any>) => Record<string, any>;
};
export declare const getUserEventMappingForPDS: (interactionResponse: any, commonData: any) => any;
export declare const getCommonUserEventMapping: (interactionResponse: any, commonData: any) => any;
//# sourceMappingURL=transferEventHandlers.d.ts.map