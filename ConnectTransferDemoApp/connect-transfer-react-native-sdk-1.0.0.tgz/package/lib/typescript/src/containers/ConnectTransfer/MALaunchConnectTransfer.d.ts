declare const MALaunchConnectTransfer: () => import("react/jsx-runtime").JSX.Element;
export default MALaunchConnectTransfer;
//# sourceMappingURL=MALaunchConnectTransfer.d.ts.map