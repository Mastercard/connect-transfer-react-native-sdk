import { type MAErrorViewProps } from './types';
declare const MAErrorView: React.FC<MAErrorViewProps>;
export default MAErrorView;
//# sourceMappingURL=MAErrorView.d.ts.map