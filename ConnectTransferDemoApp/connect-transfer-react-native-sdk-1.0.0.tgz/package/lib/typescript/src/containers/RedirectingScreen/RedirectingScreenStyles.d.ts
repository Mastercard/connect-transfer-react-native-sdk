export namespace RedirectingScreenStyle {
    namespace safeAreaView {
        let flex: number;
        let backgroundColor: string;
        let justifyContent: "center";
        let alignItems: "center";
        let gap: number;
    }
    namespace centerContainer {
        let flex_1: number;
        export { flex_1 as flex };
        let justifyContent_1: "center";
        export { justifyContent_1 as justifyContent };
        let alignItems_1: "center";
        export { alignItems_1 as alignItems };
        let gap_1: number;
        export { gap_1 as gap };
    }
    namespace text {
        let color: string;
        let fontSize: number;
        let fontWeight: "bold";
        let letterSpacing: number;
    }
    namespace redirectTextWithIcon {
        export let flexDirection: "row";
        let gap_2: number;
        export { gap_2 as gap };
        let alignItems_2: "center";
        export { alignItems_2 as alignItems };
    }
    namespace loader {
        let transform: ({
            scaleX: number;
            scaleY?: undefined;
        } | {
            scaleY: number;
            scaleX?: undefined;
        })[];
    }
}
//# sourceMappingURL=RedirectingScreenStyles.d.ts.map