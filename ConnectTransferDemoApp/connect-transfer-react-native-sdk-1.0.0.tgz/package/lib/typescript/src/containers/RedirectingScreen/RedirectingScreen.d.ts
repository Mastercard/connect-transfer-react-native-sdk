import React from 'react';
import { type RedirectingScreenProps } from '../types';
declare const RedirectingScreen: React.FC<RedirectingScreenProps>;
export default RedirectingScreen;
//# sourceMappingURL=RedirectingScreen.d.ts.map