import React from 'react';
declare const RedirectingScreen: React.FC;
export default RedirectingScreen;
//# sourceMappingURL=RedirectingScreen.d.ts.map