import React from 'react';
declare const RedirectingScreen: React.FC<{
    isExperience?: boolean;
}>;
export default RedirectingScreen;
//# sourceMappingURL=RedirectingScreen.d.ts.map