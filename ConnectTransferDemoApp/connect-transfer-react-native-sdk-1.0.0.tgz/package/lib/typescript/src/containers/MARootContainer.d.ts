import React from 'react';
import { type ConnectTransferProps } from './types';
declare const MARootContainer: React.FC<ConnectTransferProps>;
export declare function isSkipLandingPageEnabled(data: any): any;
export declare function isExperienceError(data: any): boolean;
export default MARootContainer;
//# sourceMappingURL=MARootContainer.d.ts.map