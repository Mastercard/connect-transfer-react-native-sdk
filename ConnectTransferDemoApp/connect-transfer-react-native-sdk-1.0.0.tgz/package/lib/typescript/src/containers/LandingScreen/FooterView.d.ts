export default FooterView;
declare function FooterView({ onNextPress }: {
    onNextPress: any;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=FooterView.d.ts.map