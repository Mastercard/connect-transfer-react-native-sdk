export namespace SecuredByStyle {
    namespace footer {
        let bottom: number;
        let left: number;
        let right: number;
        let padding: number;
        let flexDirection: "row";
        let justifyContent: "space-around";
    }
    namespace logoContainer {
        let flexDirection_1: "row";
        export { flexDirection_1 as flexDirection };
        export let alignItems: "center";
        export let width: number;
        export let height: number;
    }
    namespace securedText {
        let fontSize: number;
        let fontWeight: "350";
        let marginRight: number;
    }
    namespace logo {
        let resizeMode: "contain";
    }
}
export namespace LandingScreenStyle {
    namespace safeAreaView {
        let flex: number;
        let backgroundColor: string;
    }
    namespace cross {
        let marginHorizontal: number;
        let marginTop: number;
    }
    namespace loader {
        let flex_1: number;
        export { flex_1 as flex };
        let justifyContent_1: "center";
        export { justifyContent_1 as justifyContent };
    }
}
export namespace LandingScreenScrollableViewStyle {
    namespace scrollView {
        let marginHorizontal_1: number;
        export { marginHorizontal_1 as marginHorizontal };
    }
    namespace title {
        let fontSize_1: number;
        export { fontSize_1 as fontSize };
        let fontWeight_1: "bold";
        export { fontWeight_1 as fontWeight };
        export let textAlign: "left";
        let marginTop_1: number;
        export { marginTop_1 as marginTop };
        export let lineHeight: number;
        export let color: string;
    }
    namespace subtitle {
        let fontSize_2: number;
        export { fontSize_2 as fontSize };
        export let alignSelf: "center";
        let marginTop_2: number;
        export { marginTop_2 as marginTop };
        let lineHeight_1: number;
        export { lineHeight_1 as lineHeight };
        export let marginBottom: number;
        let color_1: string;
        export { color_1 as color };
    }
    namespace boldText {
        let fontWeight_2: "bold";
        export { fontWeight_2 as fontWeight };
        let color_2: string;
        export { color_2 as color };
    }
    namespace container {
        let marginTop_3: number;
        export { marginTop_3 as marginTop };
        let backgroundColor_1: string;
        export { backgroundColor_1 as backgroundColor };
    }
    namespace stepsContainer {
        let backgroundColor_2: string;
        export { backgroundColor_2 as backgroundColor };
        let padding_1: number;
        export { padding_1 as padding };
        export let paddingBottom: number;
        export let borderRadius: number;
        let marginBottom_1: number;
        export { marginBottom_1 as marginBottom };
        export let borderColor: string;
        export let borderWidth: number;
    }
    namespace headerText {
        let fontSize_3: number;
        export { fontSize_3 as fontSize };
        let fontWeight_3: "600";
        export { fontWeight_3 as fontWeight };
        let marginBottom_2: number;
        export { marginBottom_2 as marginBottom };
        let color_3: string;
        export { color_3 as color };
    }
    namespace stepItem {
        let flexDirection_2: "row";
        export { flexDirection_2 as flexDirection };
        let alignItems_1: "center";
        export { alignItems_1 as alignItems };
        export let marginVertical: number;
    }
    namespace stepNumber {
        let color_4: string;
        export { color_4 as color };
        let fontSize_4: number;
        export { fontSize_4 as fontSize };
        let fontWeight_4: "bold";
        export { fontWeight_4 as fontWeight };
        let marginRight_1: number;
        export { marginRight_1 as marginRight };
    }
    namespace stepText {
        let fontSize_5: number;
        export { fontSize_5 as fontSize };
        let color_5: string;
        export { color_5 as color };
        let lineHeight_2: number;
        export { lineHeight_2 as lineHeight };
    }
    namespace disclaimerContainer {
        let flexDirection_3: "row";
        export { flexDirection_3 as flexDirection };
        let alignItems_2: "center";
        export { alignItems_2 as alignItems };
        let marginHorizontal_2: number;
        export { marginHorizontal_2 as marginHorizontal };
        let justifyContent_2: "center";
        export { justifyContent_2 as justifyContent };
    }
    namespace disclaimerText {
        let fontSize_6: number;
        export { fontSize_6 as fontSize };
        let color_6: string;
        export { color_6 as color };
        let fontWeight_5: "500";
        export { fontWeight_5 as fontWeight };
        let lineHeight_3: number;
        export { lineHeight_3 as lineHeight };
    }
    namespace lock {
        let marginRight_2: number;
        export { marginRight_2 as marginRight };
        let resizeMode_1: "contain";
        export { resizeMode_1 as resizeMode };
        let width_1: number;
        export { width_1 as width };
        let height_1: number;
        export { height_1 as height };
    }
}
export namespace LandingScreenFooterStyle {
    export namespace safeAreaView_1 {
        let flex_2: number;
        export { flex_2 as flex };
        let backgroundColor_3: string;
        export { backgroundColor_3 as backgroundColor };
    }
    export { safeAreaView_1 as safeAreaView };
    export namespace linkIcon {
        let width_2: number;
        export { width_2 as width };
        let height_2: number;
        export { height_2 as height };
    }
    export namespace footerContainer {
        let marginHorizontal_3: number;
        export { marginHorizontal_3 as marginHorizontal };
        export let paddingTop: number;
    }
    export namespace footerText {
        let fontSize_7: number;
        export { fontSize_7 as fontSize };
        let color_7: string;
        export { color_7 as color };
        let marginHorizontal_4: number;
        export { marginHorizontal_4 as marginHorizontal };
        let alignSelf_1: "center";
        export { alignSelf_1 as alignSelf };
        let lineHeight_4: number;
        export { lineHeight_4 as lineHeight };
    }
    export namespace footerHighlight {
        let fontSize_8: number;
        export { fontSize_8 as fontSize };
        let fontWeight_6: "600";
        export { fontWeight_6 as fontWeight };
        let color_8: string;
        export { color_8 as color };
    }
    export namespace footerLink {
        let fontSize_9: number;
        export { fontSize_9 as fontSize };
        let color_9: string;
        export { color_9 as color };
        export let textDecorationLine: "underline";
        let marginBottom_3: number | undefined;
        export { marginBottom_3 as marginBottom };
    }
    export namespace button {
        let marginHorizontal_5: number;
        export { marginHorizontal_5 as marginHorizontal };
        let marginTop_4: number;
        export { marginTop_4 as marginTop };
    }
}
//# sourceMappingURL=LandingScreenStyles.d.ts.map