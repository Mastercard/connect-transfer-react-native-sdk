import React from 'react';
import { ConnectTransferEventHandler } from '../ConnectTransfer/transferEventConstants';
declare const LandingScreen: React.FC<{
    url: string;
    eventHandlers: ConnectTransferEventHandler;
}>;
export default LandingScreen;
//# sourceMappingURL=LandingScreen.d.ts.map