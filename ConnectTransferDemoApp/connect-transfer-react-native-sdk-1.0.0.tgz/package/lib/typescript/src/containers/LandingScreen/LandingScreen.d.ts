import React from 'react';
import { type LandingScreenProps } from '../types';
declare const LandingScreen: React.FC<LandingScreenProps>;
export default LandingScreen;
//# sourceMappingURL=LandingScreen.d.ts.map