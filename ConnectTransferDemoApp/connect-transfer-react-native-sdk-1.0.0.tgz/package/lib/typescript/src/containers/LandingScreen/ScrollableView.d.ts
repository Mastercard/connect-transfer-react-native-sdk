export default ScrollableView;
declare function ScrollableView(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ScrollableView.d.ts.map