declare const _exports: import("metro-config").ConfigT;
export = _exports;
//# sourceMappingURL=metro.config.d.ts.map