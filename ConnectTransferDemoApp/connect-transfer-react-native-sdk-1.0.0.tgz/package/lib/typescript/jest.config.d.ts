export let clearMocks: boolean;
export let collectCoverage: boolean;
export let coverageDirectory: string;
export let coverageProvider: string;
export let preset: string;
export let setupFilesAfterEnv: string[];
export let coverageReporters: string[];
export namespace coverageThreshold {
    namespace global {
        let branches: number;
        let functions: number;
        let lines: number;
        let statements: number;
    }
}
export let testPathIgnorePatterns: string[];
export let moduleNameMapper: {
    "^react-native$": string;
};
export let transformIgnorePatterns: string[];
//# sourceMappingURL=jest.config.d.ts.map