export const __esModule: boolean;
//# sourceMappingURL=i18n.d.ts.map