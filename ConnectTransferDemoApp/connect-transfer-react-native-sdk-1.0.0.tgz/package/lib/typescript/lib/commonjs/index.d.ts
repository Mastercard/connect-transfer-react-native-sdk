export const __esModule: boolean;
export default ConnectTransfer;
declare function ConnectTransfer({ connectTransferUrl, eventHandlers }: {
    connectTransferUrl: any;
    eventHandlers: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=index.d.ts.map