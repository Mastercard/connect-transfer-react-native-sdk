export {};
//# sourceMappingURL=errorTranslation.d.ts.map