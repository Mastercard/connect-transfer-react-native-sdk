export const __esModule: boolean;
export namespace API_KEYS {
    let authenticateUser: string;
    let termsAndPolicies: string;
    let complete: string;
    let errorTranslation: string;
}
export namespace WEBPAGE_API_KEYS {
    let privacy_EN: string;
    let privacy_ES: string;
    let termsOfUse_EN: string;
    let termsOfUse_ES: string;
}
//# sourceMappingURL=apiKeys.d.ts.map