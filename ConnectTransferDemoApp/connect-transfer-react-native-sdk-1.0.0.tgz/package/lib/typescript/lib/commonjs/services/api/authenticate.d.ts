export const __esModule: boolean;
export function authenticateUser(key: any): _toolkit.AsyncThunkAction<any, void, {
    state?: unknown;
    dispatch?: _toolkit.ThunkDispatch<unknown, unknown, _toolkit.UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=authenticate.d.ts.map