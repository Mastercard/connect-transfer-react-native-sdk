export const __esModule: boolean;
export function generateRoute(key: any, state: any): string | null;
export function requestHeaders(key: any, state: any): {
    'Content-Type': string;
    Accept: string;
};
export function createApiActions(key: any): _toolkit.AsyncThunk<any, void, {
    state?: unknown;
    dispatch?: _toolkit.ThunkDispatch<unknown, unknown, _toolkit.UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=routes.d.ts.map