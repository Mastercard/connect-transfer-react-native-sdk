export const __esModule: boolean;
export function termsAndPolicies(key: any): _toolkit.AsyncThunkAction<any, void, {
    state?: unknown;
    dispatch?: _toolkit.ThunkDispatch<unknown, unknown, _toolkit.UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
export function getData(language: any): {
    context: string;
    workflow: string;
    language: any;
    termsAndConditionsAcceptedDate: string;
    privacyPolicyAcceptedDate: string;
};
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=termsAndPolicies.d.ts.map