export const __esModule: boolean;
declare const _default: _toolkit.Reducer<{
    eventHandler: null;
}>;
export default _default;
export const setEventHandlers: _toolkit.ActionCreatorWithPayload<any, "event/setEventHandlers">;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=eventHandlerSlice.d.ts.map