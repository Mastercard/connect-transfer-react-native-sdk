export const __esModule: boolean;
export default store;
declare const store: _toolkit.EnhancedStore<{
    user: unknown;
    termsAndPolicies: unknown;
    complete: unknown;
    event: unknown;
    errorTranslation: unknown;
}, _toolkit.Action<string>, _toolkit.Tuple<[_toolkit.StoreEnhancer<{
    dispatch: _toolkit.ThunkDispatch<{
        user: unknown;
        termsAndPolicies: unknown;
        complete: unknown;
        event: unknown;
        errorTranslation: unknown;
    }, undefined, _toolkit.UnknownAction>;
}>, _toolkit.StoreEnhancer]>>;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=index.d.ts.map