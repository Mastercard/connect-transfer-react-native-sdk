export const __esModule: boolean;
export const rootReducer: _toolkit.Reducer<{
    user: unknown;
    termsAndPolicies: unknown;
    complete: unknown;
    event: unknown;
    errorTranslation: unknown;
}, _toolkit.Action<string>, Partial<{
    user: unknown;
    termsAndPolicies: unknown;
    complete: unknown;
    event: unknown;
    errorTranslation: unknown;
}>>;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=index.d.ts.map