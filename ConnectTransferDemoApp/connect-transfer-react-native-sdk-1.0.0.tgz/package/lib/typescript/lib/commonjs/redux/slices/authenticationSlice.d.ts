export const __esModule: boolean;
export const authenticateUser: _toolkit.AsyncThunk<any, void, {
    state?: unknown;
    dispatch?: _toolkit.ThunkDispatch<unknown, unknown, _toolkit.UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
declare const _default: _toolkit.Reducer<{
    modalVisible: boolean;
    url: string;
    baseURL: string;
    queryParams: string;
    queryParamsObject: {};
    language: string;
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
import _toolkit = require("@reduxjs/toolkit");
export const resetData: _toolkit.ActionCreatorWithoutPayload<"user/resetData">;
export const setUrlData: _toolkit.ActionCreatorWithPayload<any, "user/setUrlData">;
export const setUrl: _toolkit.ActionCreatorWithPayload<any, "user/setUrl">;
//# sourceMappingURL=authenticationSlice.d.ts.map