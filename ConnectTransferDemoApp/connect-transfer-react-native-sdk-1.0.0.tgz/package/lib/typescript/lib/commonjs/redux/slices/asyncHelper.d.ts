export const __esModule: boolean;
/**
 * Utility function for handling common async action states in Redux slices.
 * Manages loading, data, and error states for the provided async action.
 *
 * @param {Object} builder - The builder object for defining extra reducers.
 * @param {Function} action - The async action (thunk) to handle.
 */
export function handleAsyncActions(builder: Object, action: Function): void;
//# sourceMappingURL=asyncHelper.d.ts.map