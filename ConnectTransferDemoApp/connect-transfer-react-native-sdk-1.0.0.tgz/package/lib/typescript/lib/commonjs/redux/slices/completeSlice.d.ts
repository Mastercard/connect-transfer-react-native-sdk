export const __esModule: boolean;
export const complete: _toolkit.AsyncThunk<any, void, {
    state?: unknown;
    dispatch?: _toolkit.ThunkDispatch<unknown, unknown, _toolkit.UnknownAction>;
    extra?: unknown;
    rejectValue?: unknown;
    serializedErrorType?: unknown;
    pendingMeta?: unknown;
    fulfilledMeta?: unknown;
    rejectedMeta?: unknown;
}>;
declare const _default: _toolkit.Reducer<{
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
import _toolkit = require("@reduxjs/toolkit");
//# sourceMappingURL=completeSlice.d.ts.map