export const __esModule: boolean;
/**
 * Extracts base URL, query parameters string, and query parameters as an object from a given partner URL.
 *
 * @param {string} url - The URL from which to extract data.
 * @returns {{ baseURL: string; queryParams: string; queryParamsObject: Record<string, string> }}
 * - An object containing:
 *   - baseURL: The base URL of the partner URL.
 *   - queryParams: The raw query parameters string, including the '?' prefix.
 *   - queryParamsObject: An object mapping query parameter keys to their respective values.
 */
export function extractUrlData(url?: string): {
    baseURL: string;
    queryParams: string;
    queryParamsObject: Record<string, string>;
};
export function formatCurrentDateTime(): string;
export function getURL(language: any, type: any): string | null;
export function openLink(url: any): Promise<void>;
export function getTranslation(text: any, esJson: any): any;
//# sourceMappingURL=utils.d.ts.map