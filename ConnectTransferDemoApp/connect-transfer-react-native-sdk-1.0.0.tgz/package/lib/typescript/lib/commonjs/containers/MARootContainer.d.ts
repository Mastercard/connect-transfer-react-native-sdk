export const __esModule: boolean;
export default MARootContainer;
export function isExperienceError(data: any): boolean;
export function isSkipLandingPageEnabled(data: any): any;
declare function MARootContainer({ connectTransferUrl, eventHandlers }: {
    connectTransferUrl: any;
    eventHandlers: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MARootContainer.d.ts.map