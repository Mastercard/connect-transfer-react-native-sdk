export const __esModule: boolean;
export default MAScrollableView;
declare function MAScrollableView(): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAScrollableView.d.ts.map