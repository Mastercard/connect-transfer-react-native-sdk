export const __esModule: boolean;
export default MALandingView;
declare function MALandingView({ onNextPress }: {
    onNextPress: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MALandingView.d.ts.map