export const __esModule: boolean;
export namespace MARootContainerStyle {
    namespace safeAreaView {
        let flex: number;
        let backgroundColor: string;
    }
    namespace loader {
        let flex_1: number;
        export { flex_1 as flex };
        export let justifyContent: "center";
    }
}
export namespace MARedirectingViewStyle {
    export namespace safeAreaView_1 {
        let flex_2: number;
        export { flex_2 as flex };
        let backgroundColor_1: string;
        export { backgroundColor_1 as backgroundColor };
        let justifyContent_1: "center";
        export { justifyContent_1 as justifyContent };
        export let alignItems: "center";
        export let gap: number;
    }
    export { safeAreaView_1 as safeAreaView };
    export namespace centerContainer {
        let flex_3: number;
        export { flex_3 as flex };
        let justifyContent_2: "center";
        export { justifyContent_2 as justifyContent };
        let alignItems_1: "center";
        export { alignItems_1 as alignItems };
        let gap_1: number;
        export { gap_1 as gap };
    }
    export namespace text {
        let color: string;
        let fontSize: number;
        let fontWeight: "bold";
        let letterSpacing: number;
    }
    export namespace redirectTextWithIcon {
        export let flexDirection: "row";
        let gap_2: number;
        export { gap_2 as gap };
        let alignItems_2: "center";
        export { alignItems_2 as alignItems };
    }
    export namespace loader_1 {
        let transform: ({
            scaleX: number;
            scaleY?: undefined;
        } | {
            scaleY: number;
            scaleX?: undefined;
        })[];
    }
    export { loader_1 as loader };
}
export namespace MAErrorViewStyles {
    export namespace errorView {
        let flex_4: number;
        export { flex_4 as flex };
        export let marginHorizontal: number;
    }
    export namespace safeAreaView_2 {
        let flex_5: number;
        export { flex_5 as flex };
        let backgroundColor_2: string;
        export { backgroundColor_2 as backgroundColor };
    }
    export { safeAreaView_2 as safeAreaView };
    export namespace titleText {
        export let marginTop: number;
        let fontSize_1: number;
        export { fontSize_1 as fontSize };
        let fontWeight_1: "bold";
        export { fontWeight_1 as fontWeight };
        let color_1: string;
        export { color_1 as color };
    }
    export namespace descriptionText {
        let marginTop_1: number;
        export { marginTop_1 as marginTop };
        let fontSize_2: number;
        export { fontSize_2 as fontSize };
        let fontWeight_2: "normal";
        export { fontWeight_2 as fontWeight };
        let color_2: string;
        export { color_2 as color };
    }
    export namespace errorIcon {
        let marginTop_2: number;
        export { marginTop_2 as marginTop };
        export let alignSelf: "center";
    }
    export namespace footerView {
        let bottom: number;
        let position: "absolute";
        let width: "100%";
    }
    export namespace tryAgainButton {
        let marginHorizontal_1: number;
        export { marginHorizontal_1 as marginHorizontal };
    }
    export namespace returnToPartnerButton {
        let marginTop_3: number;
        export { marginTop_3 as marginTop };
        let marginHorizontal_2: number;
        export { marginHorizontal_2 as marginHorizontal };
        let backgroundColor_3: string;
        export { backgroundColor_3 as backgroundColor };
        export let borderWidth: number;
        export let borderColor: string;
        export let paddingVertical: number;
        let alignItems_3: "center";
        export { alignItems_3 as alignItems };
    }
    export namespace returnToPartnerText {
        let color_3: string;
        export { color_3 as color };
        let fontWeight_3: "bold";
        export { fontWeight_3 as fontWeight };
    }
}
//# sourceMappingURL=ContainerStyles.d.ts.map