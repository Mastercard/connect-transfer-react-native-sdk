export {};
//# sourceMappingURL=MALaunchConnectTransfer.d.ts.map