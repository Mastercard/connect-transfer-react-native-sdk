export const __esModule: boolean;
export default MALaunchConnectTransfer;
declare function MALaunchConnectTransfer(): _react.ReactElement<unknown, string | _react.JSXElementConstructor<any>>;
import _react = require("react");
//# sourceMappingURL=MALaunchConnectTransfer.d.ts.map