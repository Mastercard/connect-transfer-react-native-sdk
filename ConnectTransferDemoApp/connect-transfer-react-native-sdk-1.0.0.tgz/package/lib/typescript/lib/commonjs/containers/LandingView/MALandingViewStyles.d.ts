export const __esModule: boolean;
export namespace MALandingViewStyle {
    namespace cross {
        let marginHorizontal: number;
        let marginTop: number;
    }
}
export namespace MAScrollableViewStyle {
    namespace scrollView {
        let marginHorizontal_1: number;
        export { marginHorizontal_1 as marginHorizontal };
    }
    namespace title {
        export let fontSize: number;
        export let fontWeight: "bold";
        export let textAlign: "left";
        let marginTop_1: number;
        export { marginTop_1 as marginTop };
        export let lineHeight: number;
        export let color: string;
    }
    namespace subtitle {
        let fontSize_1: number;
        export { fontSize_1 as fontSize };
        export let alignSelf: "center";
        let marginTop_2: number;
        export { marginTop_2 as marginTop };
        let lineHeight_1: number;
        export { lineHeight_1 as lineHeight };
        export let marginBottom: number;
        let color_1: string;
        export { color_1 as color };
    }
    namespace boldText {
        let fontWeight_1: "bold";
        export { fontWeight_1 as fontWeight };
        let color_2: string;
        export { color_2 as color };
    }
    namespace container {
        let marginTop_3: number;
        export { marginTop_3 as marginTop };
        export let backgroundColor: string;
    }
    namespace stepsContainer {
        let backgroundColor_1: string;
        export { backgroundColor_1 as backgroundColor };
        export let padding: number;
        export let paddingBottom: number;
        export let borderRadius: number;
        let marginBottom_1: number;
        export { marginBottom_1 as marginBottom };
        export let borderColor: string;
        export let borderWidth: number;
    }
    namespace headerText {
        let fontSize_2: number;
        export { fontSize_2 as fontSize };
        let fontWeight_2: "600";
        export { fontWeight_2 as fontWeight };
        let marginBottom_2: number;
        export { marginBottom_2 as marginBottom };
        let color_3: string;
        export { color_3 as color };
    }
    namespace stepItem {
        let flexDirection: "row";
        let alignItems: "center";
        let marginVertical: number;
    }
    namespace stepNumber {
        let color_4: string;
        export { color_4 as color };
        let fontSize_3: number;
        export { fontSize_3 as fontSize };
        let fontWeight_3: "bold";
        export { fontWeight_3 as fontWeight };
        export let marginRight: number;
    }
    namespace stepText {
        let fontSize_4: number;
        export { fontSize_4 as fontSize };
        let color_5: string;
        export { color_5 as color };
        let lineHeight_2: number;
        export { lineHeight_2 as lineHeight };
    }
    namespace disclaimerContainer {
        let flexDirection_1: "row";
        export { flexDirection_1 as flexDirection };
        let alignItems_1: "center";
        export { alignItems_1 as alignItems };
        let marginHorizontal_2: number;
        export { marginHorizontal_2 as marginHorizontal };
        export let justifyContent: "center";
    }
    namespace disclaimerText {
        let fontSize_5: number;
        export { fontSize_5 as fontSize };
        let color_6: string;
        export { color_6 as color };
        let fontWeight_4: "500";
        export { fontWeight_4 as fontWeight };
        let lineHeight_3: number;
        export { lineHeight_3 as lineHeight };
    }
    namespace lock {
        let marginRight_1: number;
        export { marginRight_1 as marginRight };
        export let resizeMode: "contain";
        export let width: number;
        export let height: number;
    }
}
export namespace MAFooterViewStyle {
    namespace safeAreaView {
        export let flex: number;
        let backgroundColor_2: string;
        export { backgroundColor_2 as backgroundColor };
    }
    namespace linkIcon {
        let width_1: number;
        export { width_1 as width };
        let height_1: number;
        export { height_1 as height };
    }
    namespace footerContainer {
        let marginHorizontal_3: number;
        export { marginHorizontal_3 as marginHorizontal };
        export let paddingTop: number;
    }
    namespace footerText {
        let fontSize_6: number;
        export { fontSize_6 as fontSize };
        let color_7: string;
        export { color_7 as color };
        let marginHorizontal_4: number;
        export { marginHorizontal_4 as marginHorizontal };
        let alignSelf_1: "center";
        export { alignSelf_1 as alignSelf };
        let lineHeight_4: number;
        export { lineHeight_4 as lineHeight };
    }
    namespace footerHighlight {
        let fontSize_7: number;
        export { fontSize_7 as fontSize };
        let fontWeight_5: "600";
        export { fontWeight_5 as fontWeight };
        let color_8: string;
        export { color_8 as color };
    }
    namespace footerLink {
        let fontSize_8: number;
        export { fontSize_8 as fontSize };
        let color_9: string;
        export { color_9 as color };
        export let textDecorationLine: "underline";
        let marginBottom_3: number | undefined;
        export { marginBottom_3 as marginBottom };
    }
    namespace button {
        let marginHorizontal_5: number;
        export { marginHorizontal_5 as marginHorizontal };
        let marginTop_4: number;
        export { marginTop_4 as marginTop };
    }
}
//# sourceMappingURL=MALandingViewStyles.d.ts.map