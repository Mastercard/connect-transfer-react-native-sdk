export {};
//# sourceMappingURL=MAFooterView.d.ts.map