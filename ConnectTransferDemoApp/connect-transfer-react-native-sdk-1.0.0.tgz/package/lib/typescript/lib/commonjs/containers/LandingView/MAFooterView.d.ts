export const __esModule: boolean;
export default MAFooterView;
declare function MAFooterView({ onNextPress }: {
    onNextPress: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAFooterView.d.ts.map