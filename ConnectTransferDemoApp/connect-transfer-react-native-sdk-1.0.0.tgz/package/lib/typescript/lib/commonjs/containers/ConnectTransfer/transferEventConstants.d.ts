export const __esModule: boolean;
export const TransferEventDataName: {};
export const TransferActionEvents: {};
export const UserEvents: {};
export const RedirectReason: {};
export const AtomicEvents: {};
export const BRAND_COLOR: "#CF4500";
export const SEARCH_COMPANY: "search-company";
export const TransferModuleType: {};
//# sourceMappingURL=transferEventConstants.d.ts.map