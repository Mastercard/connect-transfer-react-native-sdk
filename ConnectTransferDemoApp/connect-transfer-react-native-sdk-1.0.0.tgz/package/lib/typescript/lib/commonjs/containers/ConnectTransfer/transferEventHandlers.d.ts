export const __esModule: boolean;
export function getTransferProductType(product: any): string | null;
export function useTransferEventCommonData(): {
    [_transferEventConstants.TransferEventDataName.CUSTOMER_ID]: any;
    [_transferEventConstants.TransferEventDataName.PARTNER_ID]: any;
    [_transferEventConstants.TransferEventDataName.TIMESTAMP]: any;
    [_transferEventConstants.TransferEventDataName.TTL]: any;
    [_transferEventConstants.TransferEventDataName.TYPE]: any;
    [_transferEventConstants.TransferEventDataName.SESSION_ID]: any;
};
export function useTransferEventResponse(): {
    getResponseForInitializeTransfer: () => {
        [_transferEventConstants.TransferEventDataName.CUSTOMER_ID]: any;
        [_transferEventConstants.TransferEventDataName.PARTNER_ID]: any;
        [_transferEventConstants.TransferEventDataName.TIMESTAMP]: any;
        [_transferEventConstants.TransferEventDataName.TTL]: any;
        [_transferEventConstants.TransferEventDataName.TYPE]: any;
        [_transferEventConstants.TransferEventDataName.SESSION_ID]: any;
    };
    getResponseForTermsAndConditionsAccepted: () => {
        [_transferEventConstants.TransferEventDataName.CUSTOMER_ID]: any;
        [_transferEventConstants.TransferEventDataName.PARTNER_ID]: any;
        [_transferEventConstants.TransferEventDataName.TIMESTAMP]: any;
        [_transferEventConstants.TransferEventDataName.TTL]: any;
        [_transferEventConstants.TransferEventDataName.TYPE]: any;
        [_transferEventConstants.TransferEventDataName.SESSION_ID]: any;
    };
    getResponseForInitializeDepositSwitch: (productType: any) => {
        [_transferEventConstants.TransferEventDataName.CUSTOMER_ID]: any;
        [_transferEventConstants.TransferEventDataName.PARTNER_ID]: any;
        [_transferEventConstants.TransferEventDataName.TIMESTAMP]: any;
        [_transferEventConstants.TransferEventDataName.TTL]: any;
        [_transferEventConstants.TransferEventDataName.TYPE]: any;
        [_transferEventConstants.TransferEventDataName.SESSION_ID]: any;
    };
    getResponseForClose: (reason: any, errorCode: any) => {
        [_transferEventConstants.TransferEventDataName.CUSTOMER_ID]: any;
        [_transferEventConstants.TransferEventDataName.PARTNER_ID]: any;
        [_transferEventConstants.TransferEventDataName.TIMESTAMP]: any;
        [_transferEventConstants.TransferEventDataName.TTL]: any;
        [_transferEventConstants.TransferEventDataName.TYPE]: any;
        [_transferEventConstants.TransferEventDataName.SESSION_ID]: any;
    };
    getResponseForFinish: (responseData: any) => any;
};
export function getUserEventMappingForPDS(interactionResponse: any, commonData: any): any;
export function getCommonUserEventMapping(interactionResponse: any, commonData: any): any;
import _transferEventConstants = require("./transferEventConstants");
//# sourceMappingURL=transferEventHandlers.d.ts.map