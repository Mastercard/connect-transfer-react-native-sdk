export const __esModule: boolean;
export default MAErrorView;
declare function MAErrorView({ isExperienceError }: {
    isExperienceError?: boolean | undefined;
}): _react.ReactElement<unknown, string | _react.JSXElementConstructor<any>>;
import _react = require("react");
//# sourceMappingURL=MAErrorView.d.ts.map