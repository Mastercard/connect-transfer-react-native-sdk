export const __esModule: boolean;
export default MALoader;
declare function MALoader({ size, color, strokeWidth, borderRadius }: {
    size?: number | undefined;
    color?: string | undefined;
    strokeWidth?: number | undefined;
    borderRadius?: number | undefined;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MALoader.d.ts.map