export const __esModule: boolean;
export default MAButton;
declare function MAButton(props: any): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAButton.d.ts.map