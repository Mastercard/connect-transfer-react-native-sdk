export const __esModule: boolean;
export default MAAttributedText;
declare function MAAttributedText({ text, styledTexts, textStyle, component }: {
    text: any;
    styledTexts: any;
    textStyle: any;
    component?: null | undefined;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAAttributedText.d.ts.map