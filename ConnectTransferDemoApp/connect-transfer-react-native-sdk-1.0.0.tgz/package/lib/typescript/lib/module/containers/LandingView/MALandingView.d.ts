export default MALandingView;
declare function MALandingView({ onNextPress }: {
    onNextPress: any;
}): React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
import React from 'react';
//# sourceMappingURL=MALandingView.d.ts.map