export default MAErrorView;
declare function MAErrorView({ isExperienceError }: {
    isExperienceError?: boolean | undefined;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAErrorView.d.ts.map