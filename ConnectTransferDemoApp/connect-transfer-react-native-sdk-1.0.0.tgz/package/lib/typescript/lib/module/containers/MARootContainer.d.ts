export function isSkipLandingPageEnabled(data: any): any;
export function isExperienceError(data: any): boolean;
export default MARootContainer;
declare function MARootContainer({ connectTransferUrl, eventHandlers }: {
    connectTransferUrl: any;
    eventHandlers: any;
}): React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
import React from 'react';
//# sourceMappingURL=MARootContainer.d.ts.map