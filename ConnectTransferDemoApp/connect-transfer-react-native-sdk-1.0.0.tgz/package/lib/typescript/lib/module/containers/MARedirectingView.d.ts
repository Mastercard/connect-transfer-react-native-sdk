export default MARedirectingView;
declare function MARedirectingView(): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MARedirectingView.d.ts.map