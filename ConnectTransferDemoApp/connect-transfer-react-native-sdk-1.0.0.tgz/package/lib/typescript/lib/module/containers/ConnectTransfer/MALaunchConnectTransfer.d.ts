export default MALaunchConnectTransfer;
declare function MALaunchConnectTransfer(): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MALaunchConnectTransfer.d.ts.map