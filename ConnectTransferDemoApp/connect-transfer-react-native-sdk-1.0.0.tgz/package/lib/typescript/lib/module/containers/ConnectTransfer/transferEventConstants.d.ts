export let TransferEventDataName: {};
export let TransferActionEvents: {};
export let TransferActionCodes: {};
export let UserEvents: {};
export let RedirectReason: {};
export let AtomicEvents: {};
export const BRAND_COLOR: "#CF4500";
export const SEARCH_COMPANY: "search-company";
export let TransferModuleType: {};
//# sourceMappingURL=transferEventConstants.d.ts.map