export function getTransferProductType(product: any): string | null;
export function useTransferEventCommonData(): {
    [TransferEventDataName.CUSTOMER_ID]: any;
    [TransferEventDataName.PARTNER_ID]: any;
    [TransferEventDataName.TIMESTAMP]: any;
    [TransferEventDataName.TTL]: any;
    [TransferEventDataName.TYPE]: any;
    [TransferEventDataName.SESSION_ID]: any;
};
export function useTransferEventResponse(): {
    getResponseForInitializeTransfer: () => {
        [x: number]: any;
    } | undefined;
    getResponseForTermsAndConditionsAccepted: () => {
        [x: number]: any;
    } | undefined;
    getResponseForInitializeDepositSwitch: (productType: any) => any;
    getResponseForError: (errorCode: any) => {
        [x: number]: any;
    };
    getResponseForClose: (reason: any, errorCode: any) => {
        [x: number]: any;
    } | undefined;
    getResponseForFinish: (responseData: any) => any;
};
export function getUserEventMappingForPDS(interactionResponse: any, commonData: any): any;
export function getCommonUserEventMapping(interactionResponse: any, commonData: any): any;
//# sourceMappingURL=transferEventHandlers.d.ts.map