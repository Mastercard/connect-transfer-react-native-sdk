export function extractUrlData(url?: string): {
    baseURL: string;
    queryParams: string;
    queryParamsObject: Record<string, string>;
};
export function formatCurrentDateTime(): string;
export function getURL(language: string, type: string): string;
export function openLink(url: string): Promise<void>;
export function getTranslation(text: any, esJson: any): any;
//# sourceMappingURL=utils.d.ts.map