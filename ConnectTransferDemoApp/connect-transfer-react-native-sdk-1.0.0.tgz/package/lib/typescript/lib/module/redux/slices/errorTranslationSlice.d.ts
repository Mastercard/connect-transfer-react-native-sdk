export const errorTranslation: any;
declare const _default: import("redux").Reducer<{
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
//# sourceMappingURL=errorTranslationSlice.d.ts.map