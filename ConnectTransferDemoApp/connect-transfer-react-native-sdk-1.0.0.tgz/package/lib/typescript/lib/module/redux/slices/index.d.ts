export const rootReducer: any;
//# sourceMappingURL=index.d.ts.map