export const setEventHandlers: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "event/setEventHandlers">;
declare const _default: import("redux").Reducer<{
    eventHandler: null;
}>;
export default _default;
//# sourceMappingURL=eventHandlerSlice.d.ts.map