export const authenticateUser: any;
export const setModalVisible: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"user/setModalVisible">;
export const setUrl: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "user/setUrl">;
export const setUrlData: import("@reduxjs/toolkit").ActionCreatorWithPayload<any, "user/setUrlData">;
export const resetData: import("@reduxjs/toolkit").ActionCreatorWithoutPayload<"user/resetData">;
declare const _default: import("redux").Reducer<{
    modalVisible: boolean;
    url: string;
    baseURL: string;
    queryParams: string;
    queryParamsObject: {};
    language: string;
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
//# sourceMappingURL=authenticationSlice.d.ts.map