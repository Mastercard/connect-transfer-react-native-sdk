export const termsAndPolicies: any;
declare const _default: import("redux").Reducer<{
    loading: boolean;
    data: null;
    error: null;
}>;
export default _default;
//# sourceMappingURL=termsAndPoliciesSlice.d.ts.map