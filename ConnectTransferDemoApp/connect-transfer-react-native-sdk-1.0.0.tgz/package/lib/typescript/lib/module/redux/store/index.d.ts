export default store;
declare const store: import("@reduxjs/toolkit").EnhancedStore<any, import("redux").UnknownAction, import("@reduxjs/toolkit").Tuple<[import("redux").StoreEnhancer<{
    dispatch: import("redux-thunk").ThunkDispatch<any, undefined, import("redux").UnknownAction>;
}>, import("redux").StoreEnhancer]>>;
//# sourceMappingURL=index.d.ts.map