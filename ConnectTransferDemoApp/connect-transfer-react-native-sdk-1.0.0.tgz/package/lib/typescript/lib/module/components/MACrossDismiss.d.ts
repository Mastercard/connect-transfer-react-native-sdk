export default MACrossDismiss;
declare function MACrossDismiss({ style, onCrossPress }: {
    style: any;
    onCrossPress: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MACrossDismiss.d.ts.map