export default MALoader;
declare function MALoader({ size, color, strokeWidth, borderRadius }: {
    size?: number | undefined;
    color?: string | undefined;
    strokeWidth?: number | undefined;
    borderRadius?: number | undefined;
}): React.ReactElement<unknown, string | React.JSXElementConstructor<any>>;
import React from 'react';
//# sourceMappingURL=MALoader.d.ts.map