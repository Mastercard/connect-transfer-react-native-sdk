export default MAExitBottomSheet;
declare function MAExitBottomSheet({ bottomSheetRef, onClose }: {
    bottomSheetRef: any;
    onClose: any;
}): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MAExitBottomSheet.d.ts.map