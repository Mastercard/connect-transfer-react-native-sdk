export default MASecuredBy;
declare function MASecuredBy(testID: any): import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
//# sourceMappingURL=MASecuredBy.d.ts.map