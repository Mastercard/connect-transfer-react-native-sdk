import { SafeAreaView, Text, Image, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';

import ErrorIcon from '../../assets/errorIcon.png';
import SecuredBy from '../../components/SecuredBy';
import MAButton from '../../components/MAButton';
import { ErrorScreenStyles as styles } from './Styles';
import { RedirectReason } from '../ConnectTransfer/transferEventConstants';
import { useTransferEventResponse } from '../ConnectTransfer/transferEventHandlers';
import { AppDispatch, type RootState } from '../../redux/store';
import { getTranslation } from '../../utility/utils';
import { resetData } from '../../redux/slices/authenticationSlice';

const ErrorScreen: React.FC<{ isExperienceError?: boolean }> = ({ isExperienceError = false }) => {
  const dispatch: AppDispatch = useDispatch();

  const { t } = useTranslation();

  const { eventHandler: transferEventHandler } =
    useSelector((state: RootState) => state.event) || null;
  const { data } = useSelector((state: RootState) => state.errorTranslation) ?? {};
  const errorData = useSelector(
    (state: RootState) => (state.user?.error as any)?.response?.data ?? {},
    shallowEqual
  );

  const { code, user_message } = errorData;
  const { getResponseForClose } = useTransferEventResponse();

  const onExitPressed = () => {
    const finalCode = isExperienceError ? -1 : code;

    if (finalCode) {
      transferEventHandler?.onTransferEnd(getResponseForClose(RedirectReason.ERROR, finalCode));
      dispatch(resetData());
    }
  };

  const ErrorScreenFooter = () => {
    return (
      <View style={styles.footerView}>
        <MAButton text={t('Exit')} style={styles.tryAgainButton} onPress={onExitPressed} />
        <SecuredBy />
      </View>
    );
  };

  const getErrorText = () => {
    if (isExperienceError) {
      return { title: t('ExperienceErrorTitle'), subTitle: `${t('ExperienceErrorSubtitle')} (-1)` };
    }

    const errorText = data && getTranslation(user_message, data);

    return {
      title: t('ErrorTitle'),
      subTitle: code && user_message ? `${errorText} (${code})` : t('ErrorSubtitle')
    };
  };

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <View style={styles.errorView}>
        <Text style={styles.titleText}>{getErrorText().title}</Text>
        <Text style={styles.descriptionText}>{getErrorText().subTitle}</Text>
        <Image source={ErrorIcon} resizeMode="contain" style={styles.errorIcon} />
        <ErrorScreenFooter />
      </View>
    </SafeAreaView>
  );
};

export default ErrorScreen;
